package com.swp391.gr3.ev_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
