package com.swp391.gr3.ev_management.events;

public record NotificationCreatedEvent(Long notificationId) { }
