package com.swp391.gr3.ev_management.enums;

public enum TripletStatus { OPEN, IN_PROGRESS, CLOSED, PAID, CANCELED }
