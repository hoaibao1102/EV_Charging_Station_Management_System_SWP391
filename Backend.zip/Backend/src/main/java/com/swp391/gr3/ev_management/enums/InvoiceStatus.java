package com.swp391.gr3.ev_management.enums;

public enum InvoiceStatus {
    PENDING, PAID, UNPAID, FAILED, CANCELLED
}
