package com.swp391.gr3.ev_management.repository;

import com.swp391.gr3.ev_management.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {

}
